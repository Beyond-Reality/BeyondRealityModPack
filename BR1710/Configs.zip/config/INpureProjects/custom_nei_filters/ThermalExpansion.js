if (FML.isModLoaded("ThermalExpansion") && ThermalExpansion_enabled){
    NEI.override("ThermalExpansion:florb", [0, 1]);
}